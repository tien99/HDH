#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define printInfo() \
	printf("Name: %s, PID: %d, PPID: %d, PGRP: %d.\n", \
			__func__, getpid(), getppid(), getpgrp());

char *gargv = NULL;
int size = 0;

void A();
void B();
void C();
void D();
void E();
void F();
void G();
void I();

void forkError() {
	perror("fork error!\n");
	exit(1);
}

void renameProcess(const char *newname) {
	strncpy(gargv, newname, size);
}

int main(int argc, char **argv) {
	gargv = argv[0];
	size = strlen(argv[0]);
	int forkA = fork();
	if (forkA < 0) {
		forkError();
	} else if (forkA == 0) {
		A();
	}
	while (1);
	return 0;
}

void A() {
	renameProcess("A");
	printInfo();
	int pidA = getpid();\
	int forkB = fork();
	if (forkB < 0) {
		forkError();
	} else if (forkB == 0) {
		B();
	}
	if (pidA == getpid()) {
		int forkC = fork();
		if (forkC < 0) {
			forkError();
		} else if (forkC == 0) {
			C();
		}
	}
	if (pidA == getpid()) {
		int forkD = fork();
		if (forkD < 0) {
			forkError();
		} else if (forkD == 0) {
			D();
		}
	}
	while (1);
}

void B() {
	renameProcess("B");
	printInfo();
	int pidB = getpid();
	int forkE = fork();
	if (forkE < 0) {
		forkError();
	} else if(forkE == 0) {
		E();
	}
	if (pidB == getpid()) {
		int forkF = fork();
		if (forkF < 0) {
			forkError();
		} else if (forkF == 0) {
			F();
		}
	}
	while (1);
}

void C() {
	renameProcess("C");
	printInfo();
	int forkG = fork();
	if (forkG < 0) {
		forkError();
	} else if (forkG == 0) {
		G();
	}
	while (1);
}

void D() {
	renameProcess("D");
	printInfo();
	while (1);
}

void E() {
	renameProcess("E");
	printInfo();
	while (1);
}

void F() {
	renameProcess("F");
	printInfo();
	while (1);
}

void G() {
	renameProcess("G");
	printInfo();
	int forkI = fork();
	if (forkI < 0) {
		forkError();
	} else if (forkI == 0) {
		I();
	}
	while(1);
}

void I() {
	renameProcess("I");
	printInfo();
	while(1);
}
